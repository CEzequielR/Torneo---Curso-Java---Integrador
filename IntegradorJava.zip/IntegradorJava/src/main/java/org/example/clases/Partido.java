package org.example.clases;
import javax.swing.*;
import java.util.Random;

import static org.example.enumeradores.Resultado.*;

public class Partido {
    //Inicializamos los elementos de esta forma para conseguir que los goles sean aleatorios.
    private int golesLocal= new Random().nextInt(1,10);
    private int golesVisitante = new Random().nextInt(1,10);

    //Constructores
    public Partido() {
    }

    public Partido(int goleslocal, int golesVisitante) {
        this.golesLocal = goleslocal;
        this.golesVisitante = golesVisitante;
    }
    //Setters and getters

    public int getGoleslocal() {
        return golesLocal;
    }
    public void setGoleslocal(int goleslocal) {
        this.golesLocal = goleslocal;
    }

    public int getGolesVisitante() {
        return golesVisitante;
    }
    public void setGolesVisitante(int golesVisitante) {
        this.golesVisitante = golesVisitante;
    }

    //Nos permite simular los partidos del torneo

    public Equipo simularPartido(Equipo equipoLocal, Equipo equipoVisitante) {
        JOptionPane.showMessageDialog(null,
                equipoLocal.getNombre() + " " + this.getGoleslocal() + " - " + this.getGolesVisitante() + " " + equipoVisitante.getNombre(),
                "Resultado", JOptionPane.INFORMATION_MESSAGE);

        equipoLocal.sumarGolesNuevos(this.getGoleslocal());
        equipoVisitante.sumarGolesNuevos(this.getGolesVisitante());

        //Aquí tendremos las 3 opciones que puede tener nuestro torneo:
        // gana equipo local, empate o gana visitante.

        if (this.golesLocal > this.golesVisitante) {
            equipoVisitante.setAutorizacion((false));
            equipoLocal.setResultado(ganador);
            equipoVisitante.setResultado(perdedor);
            JOptionPane.showMessageDialog(null,
                    "Ganó " + equipoLocal.getNombre(),
                    "Resultado", JOptionPane.INFORMATION_MESSAGE);
            return equipoLocal;
        }
        else if (this.golesLocal == this.golesVisitante) {
            JOptionPane.showMessageDialog(null,
                    "Se jugara el desempate entre " + equipoLocal.getNombre() + " - " + equipoVisitante.getNombre(),
                    "Resultado", JOptionPane.INFORMATION_MESSAGE);
            equipoLocal.setResultado(empate);
            equipoVisitante.setResultado(empate);
            simularPartido(equipoLocal, equipoVisitante);
        }
        else {
            equipoLocal.setAutorizacion(false);
            equipoLocal.setResultado(perdedor);
            equipoVisitante.setResultado(ganador);
            JOptionPane.showMessageDialog(null,
                    "Ganó " + equipoVisitante.getNombre(),
                    "Resultado", JOptionPane.INFORMATION_MESSAGE);
            return equipoVisitante;
        }
        return null;
    }
}
