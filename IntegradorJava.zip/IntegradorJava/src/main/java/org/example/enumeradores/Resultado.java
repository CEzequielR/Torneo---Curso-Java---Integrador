package org.example.enumeradores;

public enum Resultado {
    ganador, perdedor, empate
}
